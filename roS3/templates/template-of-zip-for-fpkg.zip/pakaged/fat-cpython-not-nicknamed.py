def execWAOO():
    print("Executed.")
    input("")

execWAOO()