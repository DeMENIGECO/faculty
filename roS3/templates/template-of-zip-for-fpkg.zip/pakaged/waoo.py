def WAOO():
    print("WAOO Executed.")
    input("")

WAOO()