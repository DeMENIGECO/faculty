function exec(tp = null, jp = null, trymatch = false) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSUVWXYZ123456789";

    function generateRandomId(length = 10) {
        let result = "";
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    const executionId = generateRandomId(16);

    let output = {
        status: "success",
        executionId: executionId,
        tp: tp,
        jp: jp,
        trymatch: trymatch
    };

    if (trymatch) {
        output.match = "Attempting pattern match...";
    }

    return output;
}